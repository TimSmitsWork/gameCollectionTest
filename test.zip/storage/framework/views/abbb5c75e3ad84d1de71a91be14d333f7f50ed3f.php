<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo e(config('app.name')); ?></title>
        <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
    </head>
    <body class="antialiased">
        <div id="app" class="container">
            <h1>My game collection</h1>
            <?php echo e($slot); ?>

        </div>
        <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /var/www/html/resources/views/components/layout.blade.php ENDPATH**/ ?>
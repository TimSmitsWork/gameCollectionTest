<x-layout>
    <div class="row">
        <div class="col">
            <app></app>
        </div>
    </div>
</x-layout>

<?php

return [
    'api_key' => env('RAWG_API_KEY'),
    'api_url' => env('RAWG_API_URL'),
];
